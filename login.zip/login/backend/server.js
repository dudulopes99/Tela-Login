const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bcrypt = require('bcrypt');

const app = express();
app.use(cors());
app.use(express.json());


const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',      
    password: 'User-12910', 
    database: 'sistema_login'
});

db.connect((err) => {
    if (err) return console.error('Erro ao conectar ao banco:', err);
    console.log('Conectado ao MySQL com sucesso!');
});

// Rota para Cadastro
app.post('/register', async (req, res) => {
    const { nome, email, senha } = req.body;
    try {
        const senhaHash = await bcrypt.hash(senha, 10);
        const sql = "INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)";
        db.query(sql, [nome, email, senhaHash], (err, result) => {
            if (err) {
                if (err.code === 'ER_DUP_ENTRY') return res.status(400).json({ error: 'E-mail já cadastrado.' });
                return res.status(500).json({ error: 'Erro ao cadastrar.' });
            }
            res.status(201).json({ message: 'Cadastro realizado com sucesso!' });
        });
    } catch (error) {
        res.status(500).json({ error: 'Erro no servidor.' });
    }
});

// Rota para Login
app.post('/login', (req, res) => {
    const { email, senha } = req.body;
    const sql = "SELECT * FROM usuarios WHERE email = ?";
    db.query(sql, [email], async (err, results) => {
        if (err) return res.status(500).json({ error: 'Erro no servidor.' });
        if (results.length === 0) return res.status(401).json({ error: 'E-mail ou senha incorretos.' });

        const usuario = results[0];
        const senhaValida = await bcrypt.compare(senha, usuario.senha);

        if (!senhaValida) return res.status(401).json({ error: 'E-mail ou senha incorretos.' });

        res.status(200).json({ message: 'Login realizado com sucesso!', nome: usuario.nome });
    });
});

// Inicia o servidor
app.listen(3000, () => {
    console.log('Servidor rodando na porta 3000');
});